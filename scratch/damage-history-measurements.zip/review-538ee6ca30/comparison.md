Engine budget: candidate against reference f299750a4 rebuilt on this runner (recorded 2026-11-24 on GitHub-hosted ubuntu-24.04, Intel(R) Xeon(R) 6975P-C (4 vCPU), release; tolerance 10%)

| Check | Reference | Candidate | Result |
|---|---:|---:|---|
| reference search seed 1 digest | 13638875039089371439 | 13638875039089371439 | ok |
| reference search seed 2 digest | 5466143068363283977 | 5466143068363283977 | ok |
| reference search seed 3 digest | 9998925852575961750 | 9998925852575961750 | ok |
| reference steps games | 512 | 512 | ok |
| reference steps count | 118559 | 118559 | ok |
| reference steps digest | 10601622128491155944 | 10601622128491155944 | ok |
| candidate search seed 1 digest | 13638875039089371439 | 13638875039089371439 | ok |
| candidate search seed 2 digest | 5466143068363283977 | 5466143068363283977 | ok |
| candidate search seed 3 digest | 9998925852575961750 | 9998925852575961750 | ok |
| candidate steps games | 512 | 512 | ok |
| candidate steps count | 118559 | 118559 | ok |
| candidate steps digest | 10601622128491155944 | 10601622128491155944 | ok |
| search worst reply | 1.979 s | 2.200 s | over 2.177 s (+10%) |
| search total | 77.149 s | 77.663 s | ok |
| steps throughput | 40105.5/s | 32707.9/s | under 36459.6/s (-10%) |

FAIL: 2 check(s) outside the budget. A deliberate change adopts this run as the reference: `gh run download <run-id> --name engine-budget --dir .cache/engine-budget`, then `uv run scripts/engine_budget.py record --reason "<why>"` and commit managym/perf/baseline.json (docs/development.md, Engine performance budget).
