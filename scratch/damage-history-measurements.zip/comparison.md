Engine budget: candidate against reference f299750a4 rebuilt on this runner (recorded 2026-11-24 on GitHub-hosted ubuntu-24.04, Intel(R) Xeon(R) 6975P-C (4 vCPU), release; tolerance 10%)

| Check | Reference | Candidate | Result |
|---|---:|---:|---|
| reference search seed 1 digest | 13638875039089371439 | 13638875039089371439 | ok |
| reference search seed 2 digest | 5466143068363283977 | 5466143068363283977 | ok |
| reference search seed 3 digest | 9998925852575961750 | 9998925852575961750 | ok |
| reference steps games | 512 | 512 | ok |
| reference steps count | 118559 | 118559 | ok |
| reference steps digest | 10601622128491155944 | 10601622128491155944 | ok |
| candidate search seed 1 digest | 13638875039089371439 | 13638875039089371439 | ok |
| candidate search seed 2 digest | 5466143068363283977 | 5466143068363283977 | ok |
| candidate search seed 3 digest | 9998925852575961750 | 9998925852575961750 | ok |
| candidate steps games | 512 | 512 | ok |
| candidate steps count | 118559 | 118559 | ok |
| candidate steps digest | 10601622128491155944 | 10601622128491155944 | ok |
| search worst reply | 1.564 s | 1.477 s | ok |
| search total | 61.668 s | 60.820 s | ok |
| steps throughput | 41062.3/s | 45644.9/s | ok |

PASS: within the recorded budget.
