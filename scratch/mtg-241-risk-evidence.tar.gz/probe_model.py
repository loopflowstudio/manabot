"""Bounded retained-input forward cost; run from the repository root through uv."""
import json
from pathlib import Path
import statistics
import sys
import time
from typing import cast

import numpy as np
import torch

sys.path.insert(0, str(Path('tests/verify').resolve()))
from test_retained_execution_input import CapturedObservation, _evidence
from manabot.env.observation import ObservationSpace, _timestamp_ranks
from manabot.infra.config import ModelConfig, ObservationConfig
from manabot.managym.decision_capture import DecisionInput
from manabot.model.actor_critic import ActorCritic
import managym

torch.set_num_threads(1)
space = ObservationSpace(ObservationConfig(policy_input_version=8))
arrays = []
for record in _evidence():
    capture = DecisionInput.model_validate_json(json.dumps(record.capture))
    obs = managym.Observation.from_json(json.dumps(capture.observation.viewer_state))
    encoded = space.encode(obs)
    encoded['facts'] = space.encoder._encode_facts(
        cast(managym.Observation, CapturedObservation(obs, capture.frames)),
        _timestamp_ranks(obs, shared=True),
    )
    encoded['relations'] = space.encoder._encode_relations(capture.frames, obs.agent.player_index)
    arrays.append(encoded)
full = {key: torch.from_numpy(np.stack([array[key] for array in arrays])) for key in arrays[0]}
ablated = {key: value.clone() for key, value in full.items()}
ablated['facts'][ablated['facts'][..., 1] == 14] = 0
ablated['relations'][ablated['relations'][..., 0] == 10] = 0
result = {
    'description': 'Same v8 shapes and fixed weights, native retained pairs, one CPU thread; no optimizer or training. Ablation removes retained execution facts and reference edges only; not a frozen-input comparison.',
    'input_bytes': sum(x.numel() * x.element_size() for x in full.values()),
    'facts': full['facts'][..., 11].sum(-1).tolist(),
    'relations': full['relations'][..., 31].sum(-1).tolist(),
    'models': {},
}
with torch.inference_mode():
    for kind in ['rows', 'typed_pool', 'typed_gru']:
        torch.manual_seed(241)
        model = ActorCritic(space, ModelConfig(hidden_dim=16, state_encoder=kind)).eval()
        model(full)
        model(ablated)
        samples = {'full': [], 'ablated': []}
        for i in range(7):
            for label in (['full', 'ablated'] if i % 2 == 0 else ['ablated', 'full']):
                start = time.perf_counter_ns()
                model(full if label == 'full' else ablated)
                samples[label].append(time.perf_counter_ns() - start)
        result['models'][kind] = samples
        print(kind, {label: round(statistics.median(times) / 1e6, 3) for label, times in samples.items()})
Path('.cache/mtg241-execution-risk/model-cost-final.json').write_text(json.dumps(result, indent=2) + '\n')
print('facts', result['facts'], 'relations', result['relations'], 'bytes', result['input_bytes'])
