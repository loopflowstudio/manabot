Engine budget: candidate against reference f299750a4 rebuilt on this runner (recorded 2026-11-24 on GitHub-hosted ubuntu-24.04, Intel(R) Xeon(R) 6975P-C (4 vCPU), release; tolerance 10%)

| Check | Reference | Candidate | Result |
|---|---:|---:|---|
| reference search seed 1 digest | 13638875039089371439 | 13638875039089371439 | ok |
| reference search seed 2 digest | 5466143068363283977 | 5466143068363283977 | ok |
| reference search seed 3 digest | 9998925852575961750 | 9998925852575961750 | ok |
| reference steps games | 512 | 512 | ok |
| reference steps count | 118559 | 118559 | ok |
| reference steps digest | 10601622128491155944 | 10601622128491155944 | ok |
| candidate search seed 1 digest | 13638875039089371439 | 13638875039089371439 | ok |
| candidate search seed 2 digest | 5466143068363283977 | 5466143068363283977 | ok |
| candidate search seed 3 digest | 9998925852575961750 | 9998925852575961750 | ok |
| candidate steps games | 512 | 512 | ok |
| candidate steps count | 118559 | 118559 | ok |
| candidate steps digest | 10601622128491155944 | 10601622128491155944 | ok |
| search worst reply | 1.442 s | 1.759 s | over 1.587 s (+10%) |
| search total | 58.847 s | 68.132 s | over 64.732 s (+10%) |
| steps throughput | 42519.9/s | 39002.9/s | ok |

FAIL: 2 check(s) outside the budget. A deliberate change adopts this run as the reference: `gh run download <run-id> --name engine-budget --dir .cache/engine-budget`, then `uv run scripts/engine_budget.py record --reason "<why>"` and commit managym/perf/baseline.json (docs/development.md, Engine performance budget).
